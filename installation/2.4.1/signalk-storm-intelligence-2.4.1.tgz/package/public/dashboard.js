'use strict'
const API='/plugins/signalk-storm-intelligence/operational'
const $=id=>document.getElementById(id)
let timer=null
const fmtNm=m=>Number.isFinite(Number(m))?`${(Number(m)/1852).toFixed(Number(m)<18520?1:0)} NM`:'—'
const fmtPct=x=>Number.isFinite(Number(x))?`${Math.round(Number(x)*100)}%`:'—'
function fmtDuration(sec){if(!Number.isFinite(Number(sec)))return '—';sec=Math.max(0,Math.round(Number(sec)));const h=Math.floor(sec/3600),m=Math.floor((sec%3600)/60);if(h)return `${h}h ${m}m`;if(m)return `${m} min`;return `${sec}s`}
function fmtTime(iso){const d=new Date(iso);return Number.isNaN(d.getTime())?'—':d.toLocaleTimeString([],{hour:'2-digit',minute:'2-digit',second:'2-digit'})}
function esc(v){return String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
function stateBadge(state){const s=String(state||'unknown').toLowerCase();return `<span class="badge ${esc(s)}">${esc(s)}</span>`}
function evidence(cell){const bits=[];if(cell.severity!=null)bits.push(`severity ${cell.severity}`);bits.push(`confidence ${fmtPct(cell.confidence)}`);if(cell.lightning?.count10min)bits.push(`${cell.lightning.count10min} lightning / 10m`);if(cell.lightning?.jump)bits.push('lightning jump');if(cell.threatMethod)bits.push(cell.threatMethod);return bits.join(' · ')}
function inferenceDetails(component){
 if(component.state==='disabled')return 'Inference disabled'
 const run=component.lastRun
 if(run)return `${run.ok?'last run OK':'last run failed'} · ${run.durationMs??'—'} ms · ${run.count??0} cells${run.error?` · ${esc(run.error)}`:''}`
 if(component.processedAt!=null){
  const observedAt=new Date(component.processedAt)
  if(Number.isFinite(observedAt.getTime()))return `Last processed observation · ${esc(observedAt.toISOString())}`
 }
 return 'Waiting for first inference cycle'
}
function componentDetails(c){if(c.id.startsWith('radar:')){const age=Number.isFinite(c.ageMs)?`${Math.round(c.ageMs/60000)} min old`:'age unknown';return `${esc(c.provider)} · ${esc(c.product)} · ${age}`}
 if(c.id.startsWith('inference:'))return inferenceDetails(c)
 if(c.id==='lightning')return `${c.observationCount||0} current observations · ${(c.providers||[]).length} provider(s)`
 if(c.id==='storm-source')return `${c.cellCount||0} tracked cells · source ${esc(c.source||'—')}`
 if(c.id==='acquisition'||c.id==='prefetch')return `${(c.targets||[]).length} target(s)`
 if(c.id==='weather-api')return `${c.sampleCount||0} weather sample(s)`
 if(c.id==='onboard-environment')return c.evidence?.available?'Signal K environmental evidence available':'No current onboard evidence'
 return esc(c.message||'')}
function renderCells(rows){const body=$('cellsBody');if(!rows.length){body.innerHTML='<tr><td colspan="7" class="empty">No approaching cells within the configured inference horizon.</td></tr>';return}
 body.innerHTML=rows.map(c=>{const eta=c.eta?`${c.eta.type==='impact'?'<span class="eta-impact">':'<span class="eta-ca">'}${c.eta.type==='impact'?'Impact':'Closest approach'} ${fmtDuration(c.eta.seconds)}</span><div class="sub">${fmtTime(c.eta.at)}</div>`:'—';const ca=c.closestApproach?`${fmtNm(c.closestApproach.distanceMeters)}${c.closestApproach.seconds!=null?`<div class="sub">in ${fmtDuration(c.closestApproach.seconds)}</div>`:''}`:'—';return `<tr><td><div class="risk-score"><span class="risk-dot ${esc(c.risk.label)}"></span><span class="risk-number">${c.risk.score}</span></div><div class="sub">${esc(c.risk.label)} · ${esc(c.state)}</div></td><td><strong>${esc(c.id)}</strong><div class="sub">${esc(c.observedAt||'time unavailable')}</div></td><td>${eta}</td><td>${fmtNm(c.distanceMeters)}</td><td>${ca}</td><td>${esc(evidence(c))}${c.uncertaintyMeters!=null?`<div class="sub">uncertainty ${fmtNm(c.uncertaintyMeters)}</div>`:''}</td><td>${esc(c.provider||'—')}<div class="sub">${esc(c.product||'')}</div></td></tr>`}).join('')}
function renderComponents(rows){$('components').innerHTML=rows.map(c=>`<article class="component"><div class="component-top"><div class="component-name">${esc(c.name)}</div>${stateBadge(c.state)}</div><div class="component-detail">${componentDetails(c)}</div></article>`).join('')||'<div class="empty">No component information.</div>'}
function render(data){$('connection').className='badge healthy';$('connection').textContent='Live';$('overallState').innerHTML=stateBadge(data.storm?.state||data.runtime?.state);$('overallMessage').textContent=data.storm?.message||'No active storm message';$('approachingCount').textContent=data.storm?.approachingCells??0;$('totalCells').textContent=`${data.storm?.totalCells??0} tracked`;const bad=(data.componentSummary?.error||0)+(data.componentSummary?.warning||0);$('componentHealth').textContent=bad?`${bad} attention`:'Nominal';$('componentSummary').textContent=Object.entries(data.componentSummary||{}).map(([k,v])=>`${v} ${k}`).join(' · ')||'—';$('lastUpdate').textContent=fmtTime(data.generatedAt);const age=Math.max(0,Date.now()-new Date(data.generatedAt).getTime());$('dataAge').textContent=`dashboard data ${Math.round(age/1000)}s old`;$('version').textContent=data.runtime?.version||'—';$('horizon').textContent=`${data.storm?.horizonMinutes??'—'} min`;const p=data.vessel?.position;$('vesselPosition').textContent=p&&Number.isFinite(Number(p.latitude))&&Number.isFinite(Number(p.longitude))?`${Number(p.latitude).toFixed(4)}, ${Number(p.longitude).toFixed(4)}`:'Unavailable';$('riskSemantics').textContent=data.semantics?.risk||'';renderCells(data.approachingCells||[]);renderComponents(data.components||[])}
async function load(){try{const res=await fetch(API,{headers:{accept:'application/json'},cache:'no-store'});if(!res.ok)throw new Error(`HTTP ${res.status}`);render(await res.json())}catch(e){$('connection').className='badge error';$('connection').textContent='Unavailable';$('overallMessage').textContent=`Operational API unavailable: ${e.message}`}}
function schedule(){clearInterval(timer);timer=setInterval(()=>{if(!document.hidden)load()},10000)}
$('refresh').addEventListener('click',load);document.addEventListener('visibilitychange',()=>{if(!document.hidden)load()});load();schedule()
